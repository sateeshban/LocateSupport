import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-trade-manager',
  templateUrl: './trade-manager.component.html'
})
export class TrademanagerComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
