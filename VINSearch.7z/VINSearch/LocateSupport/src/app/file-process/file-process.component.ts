import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-file-process',
  templateUrl: './file-process.component.html'
})
export class FileProcessComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
