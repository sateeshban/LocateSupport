import { Http,Headers,Request,Response,RequestOptions } from '@angular/http'
import { BaseService } from './base.service';
import { Router } from '@angular/router';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import{ map } from 'rxjs/operators';
import { environment   } from '../../environments/environment'


@Injectable()
export class TokenService extends BaseService {
    /**
     *
     */
    constructor(private _http: Http, router : Router) {
        super(_http,router);
    }
    

    public getTokens() : Observable<any>{
        return this.get(environment.api_path+"GetTokens")
        .pipe(map((response)=> {
            console.log(response);
              return response;
        }));
    }
   

}
