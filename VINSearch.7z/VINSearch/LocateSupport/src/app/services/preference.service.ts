import { Observable } from 'rxjs';
import { Injectable, Output } from '@angular/core';
import { CommonModalComponent } from '../common/modal/common.modal.component';
import { DialogModel } from '../models/dialogModel';
import { NgbModal, NgbActiveModal, NgbModalOptions } from '@ng-bootstrap/ng-bootstrap';
import { user } from '../models/user';

@Injectable()
export class PreferenceService {
  //mock data
  public token = ['zzz', 'yyy'];
  public usersList: user[] = [
    ];
  constructor() { }
  public getLoggedInUserDetails(cdsid: string): user {
    return this.usersList.find(x => x.cdsid === cdsid);
  }
  public saveUserLandingPage(landingPage: string): void {
    // save landing page to backend
  }
}
