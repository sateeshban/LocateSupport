import { Observable } from 'rxjs';
import { Injectable, Output } from '@angular/core';
import { CommonModalComponent } from '../common/modal/common.modal.component';
import { DialogModel } from '../models/dialogModel';
import { NgbModal, NgbActiveModal, NgbModalOptions } from '@ng-bootstrap/ng-bootstrap';
import { user } from '../models/user';
import { HttpClient, HttpParams, HttpErrorResponse, HttpHeaders } from '@angular/common/http';

@Injectable()
export class PreferenceService {

  
  //mock data
  readonly baseURL = 'http://localhost:60750/api'
    urlString: any;
  public token = ['zzz', 'yyy'];
  public usersList: user[] = [
    ];
    constructor(private httpClient: HttpClient) {
    }
  public getLoggedInUserDetails(cdsid: string): user {
    return this.usersList.find(x => x.cdsid === cdsid);
  }
  public saveUserLandingPage(user:any): any {
    const data = {
          
      Preference: user.Preference,
      CDSID: user.cdsid,
          
  };
  const userModel = JSON.stringify(data);
  const h = new HttpHeaders({'Content-Type': 'application/json'});
  return this.httpClient.post<user>(`${this.baseURL}/admin/UserPreference`, userModel, {headers: h});
  }
}
