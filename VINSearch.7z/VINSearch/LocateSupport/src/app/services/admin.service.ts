import { Observable } from 'rxjs';
import { Injectable, Output } from '@angular/core';
import { CommonModalComponent } from '../common/modal/common.modal.component';
import { DialogModel } from '../models/dialogModel';
import { NgbModal, NgbActiveModal, NgbModalOptions } from '@ng-bootstrap/ng-bootstrap';
import { user } from '../models/user';

@Injectable()
export class AdminService {
   userexistance: boolean;
   
  //mock data
  public usersList: user[] = [
   
  ];
  constructor() { 
     this.userexistance = true;
  }
  public getUsersByCdsid(searchKey: string): user {  
    debugger; 
    return this.usersList.find(x => x.cdsid === searchKey);
  }
}
