import { Observable } from 'rxjs';
import { Injectable, Output } from '@angular/core';
import { CommonModalComponent } from '../common/modal/common.modal.component';
import { DialogModel } from '../models/dialogModel';
import { NgbModal, NgbActiveModal, NgbModalOptions } from '@ng-bootstrap/ng-bootstrap';
import { user } from '../models/user';
import { HttpClient, HttpParams, HttpErrorResponse, HttpHeaders } from '@angular/common/http';

@Injectable()
export class AdminService {
  readonly baseURL = 'http://localhost:60750/api'
  urlString: any;
   userexistance: boolean;
   
  //mock data
  public usersList: user[] = [
   
  ];
  constructor(private httpClient:HttpClient) { 
     //this.userexistance = true;
  }
  public getUsersByCdsid(searchKey: string): user {  
   
    return this.usersList.find(x => x.cdsid === searchKey);
  }
  getRemoveUsersByCdsid(removeKey): any {  
      return this.httpClient.get(`${this.baseURL}/admin/RemoveUser/${removeKey}`);
   }
}
