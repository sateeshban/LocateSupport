import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-user-detail',
  templateUrl: './detail-user.component.html'
})
export class DetailUserComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
