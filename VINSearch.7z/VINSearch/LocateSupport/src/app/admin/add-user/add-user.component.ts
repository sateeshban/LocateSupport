import { Component, OnInit } from '@angular/core';
import {Router} from '@angular/router'
import { NgbModal,NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { DialogModel } from '../../models/dialogModel';
import { DataTableResponse } from '../../models/dataTableResponse';
import { TokenService } from '../../services/add-user.service';
import { Http } from '@angular/http';
import { BaseService } from '../../services/base.service';
import { CommonModalComponent } from '../../common/modal/common.modal.component';
import { ModalService } from '../../services/ModalService';
import { Observable,from } from 'rxjs';


@Component({
  selector: 'app-user-add',
  templateUrl: './add-user.component.html',
  providers : [TokenService]
})
export class CreateUserComponent implements OnInit {
TokenList:Array<string>
isHavingEmptyRecords : boolean = false;
constructor(
  private modalService: ModalService, 
  private router: Router,
  private tokenService: TokenService,
  private currentModal: NgbActiveModal 
  ) {   }

  ngOnInit() {
    this.TokenList=[];
    this.getTokens()
  }
  getTokens(): void {
     this.tokenService.getTokens().subscribe((response : any) => {
       this.TokenList = response;
       console.log(response);
       if(response.length == 0){
         this.isHavingEmptyRecords = true;
       }
    });
  }

}





