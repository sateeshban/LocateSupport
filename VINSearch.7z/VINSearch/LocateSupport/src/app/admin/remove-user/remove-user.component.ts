import { Component, OnInit } from '@angular/core';
import { user } from '../../models/user';
import { AdminService } from '../../services/admin.service';

@Component({
  selector: 'app-user-remove',
  templateUrl: './remove-user.component.html'
})
export class RemoveUserComponent implements OnInit {

 searchKey: string;
 removeUsersList: user; 

  constructor(private adminService: AdminService) { }

  ngOnInit() {  
  }
  public search(): void{
    if (this.searchKey) {
      debugger;
      this.removeUsersList = this.adminService.getUsersByCdsid(this.searchKey);
    debugger;
    }
  }
}
