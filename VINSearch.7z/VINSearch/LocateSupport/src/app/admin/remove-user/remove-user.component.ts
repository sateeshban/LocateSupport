import { Component, OnInit } from '@angular/core';
import { user } from '../../models/user';
import { AdminService } from '../../services/admin.service';

@Component({
  selector: 'app-user-remove',
  templateUrl: './remove-user.component.html'
})
export class RemoveUserComponent implements OnInit {

 searchKey: string;
 removeUsersList: user; 
 removeKey:string;
 ConfirmMessage:any;
 isError:any;
  constructor(private adminService: AdminService) { }

  ngOnInit() {  
  }
   search(){
    if (this.searchKey) {
     this.removeUsersList = this.adminService.getUsersByCdsid(this.searchKey);
    }
  }
   removeUser(){
    if (this.removeKey) {
      this.adminService.getRemoveUsersByCdsid(this.removeKey).subscribe((resp: any) => {
       this.isError=false;
        this.ConfirmMessage=resp;
       },
       err => {
        this.isError=true;
        this.ConfirmMessage="Error:"+err["error"].ExceptionMessage;
      })
    
    }
  }
}


