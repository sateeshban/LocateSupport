import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-user-remove',
  templateUrl: './remove-user.component.html'
})
export class RemoveUserComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
