import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-user-list',
  templateUrl: './list-user.component.html'
})
export class UserListComponent implements OnInit {
 showSidebar = false;
  constructor() { }

  ngOnInit() {
      this.showSidebar = true;
  }


}
