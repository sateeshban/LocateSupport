export class DialogModel {
   
    constructor() {
        
    }
    title : string ="";
    isCancelEnabled : boolean = false;
    btnOkText: string ="";
    btnCancelText = "";
    body:string ="";
}