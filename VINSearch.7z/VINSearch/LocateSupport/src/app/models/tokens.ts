export class tokens
{
    tokens : any[];
}