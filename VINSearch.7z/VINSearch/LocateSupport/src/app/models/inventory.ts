export  class Inventory {
    constructor() {
    
    }

    ProductId : number = null;
    ProductName : string = "";
    Supplier : string = "";
    Quantity : number = null;
    UnitPrice : number = null;
    TotalCost : number = null;
    SupplierName:string ="";
    IsActive: boolean = true;
    
} 