export class Supplier {
    constructor() {
       
    }

    SupplierId : number = 0;
    SupplierName : string = "";
    Address : string = "";
}