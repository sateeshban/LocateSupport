export class DataTableResponse {
    data : any[];
    draw : number;
    recordsFiltered : number;
    recordsTotal : number
}