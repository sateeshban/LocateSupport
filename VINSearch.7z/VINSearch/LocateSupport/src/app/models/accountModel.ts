export class AccountModel{

    AccountId : number;
    AccountName : string;
    Password : string;
    FirstName : string;
    LastName : string
}