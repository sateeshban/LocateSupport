import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-prefrences',
  templateUrl: './prefrences.component.html'
})
export class PrefrencesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
