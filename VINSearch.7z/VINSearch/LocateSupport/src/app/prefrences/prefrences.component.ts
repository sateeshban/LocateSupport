import { Component, OnInit } from '@angular/core';
import { user } from '../models/user';
import { PreferenceService } from '../services/preference.service';

@Component({
  selector: 'app-prefrences',
  templateUrl: './prefrences.component.html',
  providers: [PreferenceService]
})
export class PrefrencesComponent implements OnInit {
  constructor(private preferenceService: PreferenceService) {
  }
  user: user = new user();
  landingPages: any = ['VIN Search','Trade Manager','Dealer Search','Reports','File Process'];
  landingPage: string = this.landingPages[0];
  ngOnInit() {
    let cdsid = 'user1'; // get logged in user details from local storage
    this.getLoggedInUserDetails(cdsid);
  }
  public getLoggedInUserDetails(cdsid:string) : void {
    this.user = this.preferenceService.getLoggedInUserDetails(cdsid);
  }
  public saveLandingPage():void {
     this.preferenceService.saveUserLandingPage(this.landingPage);
  }

}
