import { Component, OnInit } from '@angular/core';
import { user } from '../models/user';
import { PreferenceService } from '../services/preference.service';

@Component({
  selector: 'app-prefrences',
  templateUrl: './prefrences.component.html',
  providers: [PreferenceService]
})
export class PrefrencesComponent implements OnInit {
  constructor(private preferenceService: PreferenceService) {
  }
  user: user = new user();
  ngOnInit() {
    let cdsid = localStorage.getItem('CDSID'); 
    this.getLoggedInUserDetails(cdsid);
  }
  public getLoggedInUserDetails(cdsid:string){
       this.user = this.preferenceService.getLoggedInUserDetails(cdsid).subscribe((resp: any) => {
       this.user.firstname = resp.data.FirstName;
       this.user.lastname = resp.data.LastName;
       this.user.department = resp.data.Department;
       this.user.company = resp.data.Company;
       this.user.cdsid = resp.data.CDSID;
       this.user.tokens = resp.data.TokenList;
       this.user.preference=resp.data.Preference;
       
     })
  
  }
  public saveLandingPage(){
    this.preferenceService.saveUserLandingPage(this.user).subscribe((resp: any) => {
    },
    err => {
     console.log(err.ConfirmMessage)
    })
 }
  onSelect(selectedToken:any) { 
      this.user.preference = null;
      this.user.preference = selectedToken;
      }
    

}
