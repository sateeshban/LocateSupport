import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dealer-search',
  templateUrl: './dealer-search.component.html'
})
export class DealerSearchComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
