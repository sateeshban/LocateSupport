import { Component, Input, OnInit } from '@angular/core';
import { BehaviorSubject } from 'rxjs';
import { Router } from '@angular/router';
import { LoginService } from '../app/login/login.service';
//'' '..\login\login.service.ts'
declare var $: any;

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit{
  title = 'app';
  loader = false;
  showSidebar = false;
  showSideAdmin=false;
  showSidePreferences=false;
  welcomeName = '';
@Input() isLoggedIn: boolean = false;
private loggedIn = new BehaviorSubject<boolean>(false);

constructor(private router: Router, private loginService: LoginService){
}

ngOnInit(): void {
  // Setup a subscription so our variable will know the latest status of login
  // this.loginService.isLoggedIn().subscribe(status => this.isUserLoggedIn = status);
  // this.loginService.isAuthenticated;
}

  get isAuth(): boolean {
    return localStorage.getItem('isAuth') === 'true' ? true : false;
  }

  get welcomeUser(): string {
    return localStorage.getItem('welcomeUser');
  }

  openSideBarAdmin () {
    this.showSidebar = true;
    this.showSideAdmin=true;
    this.showSidePreferences=false;
  }
  openSideBarPreferences(){
    this.showSidebar = true;
    this.showSidePreferences=true;
    this.showSideAdmin=false;
  }

  SignOut() {
    debugger;
    this.loginService.authSignOut();
    // localStorage.removeItem('token');
    // localStorage.setItem('isAuth', 'false');
    // this.router.navigateByUrl('/');

    // history.pushState(null, null, 'nopage');
    // window.addEventListener('popstate', function (event) {
    //   history.pushState(null, null, 'nopage');
    // }); // back button disable [ended]
  }
}