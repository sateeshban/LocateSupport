import { Component, OnInit } from "@angular/core";
import { FormGroup, FormBuilder, Validators } from "@angular/forms";
import { Router } from "@angular/router";
import { LoginService } from "./login.service";
import { Observable} from 'rxjs';
import { validateConfig } from "@angular/router/src/config";
import{ TokenModel } from '../models/tokenModel';
import { AccountModel } from "../models/accountModel";
import { HttpService } from '../services/http.service';
import { user } from "../models/user";

@Component({
    templateUrl: "./login.component.html",
    styleUrls : ["./login.component.css"]
})
export class LoginComponent implements OnInit{
 
    loginFormGroup: FormGroup;
    errMessage = '';
    isLoggedIn: Observable<boolean>;
    user:user;
    
    constructor(private formBuilder: FormBuilder, private router: Router, private loginService: LoginService,private httpService:HttpService) 
    { }

    ngOnInit(){
        this.loginFormGroup = this.formBuilder.group({
            Username : ['',Validators.required],
            Password : ['',Validators.required]
        });
        debugger;
      this.UserLogin();
        this.isLoggedIn = this.loginService.IsUserLoggedIn;
    }

    LoginFormValidation(){
        Object.keys(this.loginFormGroup.controls).forEach(field=>{
            const control = this.loginFormGroup.get(field);
            control.markAsTouched({onlySelf:true});
        })
    }

    UserLogin() {
        this.errMessage="";
        if(!this.loginFormGroup.valid){
            this.LoginFormValidation();
            return false;
        }
            
     this.user= this.httpService.getUser(this.loginFormGroup.value.Username)
          .subscribe((response: any) => {
                 if (response)  {
                    localStorage.setItem('token', response.data.CDSID);
                    localStorage.setItem('CDSID', response.data.CDSID);
                    localStorage.setItem('isAuth', 'true');
                   this.getUserAccountDetails(response.data.Preference);
                } else {
                    this.errMessage = 'Invalid username and password.';
                }
            },
            (error) => {
                this.errMessage = 'Invalid username and password.';
            }
       );
        // this.loginService.validateUser(this.loginFormGroup.value.Username,this.loginFormGroup.value.Password)
        //   .subscribe(
        //     (response: TokenModel) => {
        //         if (response && response.access_token) {
        //             localStorage.setItem('token', response.access_token);
        //             localStorage.setItem('isAuth', 'true');
        //            this.getUserAccountDetails();
        //         } else {
        //             this.errMessage = 'Invalid username and password.';
        //         }
        //     },
        //     (error) => {
        //         this.errMessage = 'Invalid username and password.';
        //     }
      //  );
    }

  getUserAccountDetails(url:string) {
      if(url=="LS_VINSearch")
      {
        this.router.navigateByUrl('/vinsearch');
      }
      else if(url=="LS_TradeManager")
      {
    this.router.navigateByUrl('/trademanager');
      }
     else if(url=="LS_DealerSearch")
      {
        this.router.navigateByUrl('/dealersearch');
      }
      else if(url=="LS_Reports")
      {
        this.router.navigateByUrl('/reports');
      }
      else if(url=="LS_FileProcess")
      {
        this.router.navigateByUrl('/fileprocess');
      }
      else if(url=="LS_Admin")
      {
        this.router.navigateByUrl('/users');
      }
      else 
      {
        this.router.navigateByUrl('/vinsearch');
      }
        // this.loginService.getAccountDetails(this.loginFormGroup.value.Username)
        //     .subscribe(
        //         (response: AccountModel) => {
        //             localStorage.setItem('welcomeUser', response.FirstName + ' ' + response.LastName);
        //             this.router.navigateByUrl('/inventories');
        //     });
    }


    

}