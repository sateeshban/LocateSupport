import { TestBed, ComponentFixture } from "@angular/core/testing";
import { LoginComponent } from "./login.component";
import { LoginService } from "./login.service";
import { Observable, of } from "../../../node_modules/rxjs";
import { AccountModel } from "../models/accountModel";
import { Router } from "@angular/router";
import { FormsModule,FormGroup,FormBuilder,ReactiveFormsModule  } from "@angular/forms";
import { HttpModule } from "@angular/http";
import { BrowserModule } from "@angular/platform-browser";
import { NO_ERRORS_SCHEMA } from "@angular/core";

describe("Login Component", () => {
    // declare login component fixture
    let loginFixture: ComponentFixture<LoginComponent>;
    beforeEach(() => {
        TestBed.configureTestingModule({
            schemas : [NO_ERRORS_SCHEMA],
            imports: [
                BrowserModule,
                    HttpModule,
                    ReactiveFormsModule,
                    FormsModule

            ],
            declarations: [
                LoginComponent
            ],
            providers: [
                { provide: LoginService, useClass: MockLoginService },
                {provide : Router, useClass : RouterStub}
            ]
        }).compileComponents();
        debugger;

        //  create Instance for login component
        loginFixture = TestBed.createComponent(LoginComponent);
    });

    it("Get User Login Details", () => {
        debugger;
        loginFixture.componentInstance.loginFormGroup.value.Username ="bhushan";
        loginFixture.componentInstance.loginFormGroup.value.Password ="bhushan";
        loginFixture.componentInstance.getUserAccountDetails();

    })
});

export class MockLoginService{
    /**
     *
     */
    constructor() {
      
    }

    validateUser(userName:string,password:string) : Observable<AccountModel>{
        return of({
            "AccountId" : 1,
            "AccountName" : "bhushan",
            "Password" : "bhushan",
            "FirstName" : "bhushan",
            "LastName" : "shweth"
        });
    }
}

class RouterStub {
    navigateByUrl(url : string) { return url; }
    navigate(){}
}